package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dto.Student;
import com.example.service.StudentService;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class HomeController {
    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
    private final StudentService studentService;

    public HomeController(StudentService studentService) {
        this.studentService = studentService;
    }

    @RequestMapping("/")
    public String home(Model model) {

        logger.info("Hello, SLF4J!");
        logger.debug("Debug message: {}", 123);
        logger.warn("This is a warning!");
        //logger.error("Error occurred!", new RuntimeException("Test Exception"));

        List<Student> students = studentService.getAllStudents();
        model.addAttribute("message", "Hello, Spring MVC!");
        model.addAttribute("students", students);
        return "home";
    }
}
