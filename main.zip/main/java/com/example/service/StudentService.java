package com.example.service;

import com.example.dto.Student;
import com.example.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Integer id) {
        return studentRepository.findById(id);
    }

    @Transactional
    public void addStudent(Student student) {
        studentRepository.insert(student);
    }

    @Transactional
    public void updateStudent(Student student) {
        studentRepository.update(student);
    }

    @Transactional
    public void deleteStudent(Integer id) {
        studentRepository.delete(id);
    }
}
